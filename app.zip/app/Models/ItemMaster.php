<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemMaster extends Model
{
    protected $table = 'umitemmaster';
    protected $primaryKey = 'ID';

    const CREATED_AT = 'CreatedOn';
    const UPDATED_AT = 'UpdatedOn';

    protected $fillable = [
        'ItemName',
        'PartNo',
        'CatalogueNo',
        'MinQuantity',
        'Department',
        'HSNNo',
        'GSTPercentage',
        'RackNo',
        'IsActive',
        'CreatedBy',
        'UpdatedBy',
    ];

    protected $casts = [
        'MinQuantity' => 'float',
        'GSTPercentage' => 'float',
        'IsActive' => 'boolean',
        'CreatedOn' => 'datetime',
        'UpdatedOn' => 'datetime',
    ];

    public function departmentRelation()
    {
        return $this->belongsTo(Department::class, 'Department', 'ID');
    }
}
